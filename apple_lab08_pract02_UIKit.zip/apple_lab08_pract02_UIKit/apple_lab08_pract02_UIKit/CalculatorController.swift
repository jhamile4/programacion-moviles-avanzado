
import UIKit

class CalculatorController: UIViewController {

    // MARK: - Conexiones (Outlets)
    @IBOutlet weak var firstNumberTextField: UITextField!
    @IBOutlet weak var secondNumberTextField: UITextField!
    @IBOutlet weak var calcularButton: UIButton!
    @IBOutlet weak var resultLabel: UILabel! // Conecta tu nuevo Label aquí
    @IBOutlet weak var operationButton: UIButton!
    
   
    var selectedOperation: String = "+"

    override func viewDidLoad() {
        super.viewDidLoad()
        setupMenu()
        firstNumberTextField.keyboardType = .decimalPad
        secondNumberTextField.keyboardType = .decimalPad
        resultLabel.text = "Result"
    }

    
    func setupMenu() {
        let suma = UIAction(title: "Addition (+)", image: nil) { _ in
            self.selectedOperation = "+"
            self.operationButton.setTitle("Addition (+)", for: .normal)
        }
        let resta = UIAction(title: "Subtraction (-)", image: nil) { _ in
            self.selectedOperation = "-"
            self.operationButton.setTitle("Subtraction (-)", for: .normal)
        }
        let multi = UIAction(title: "Multiplication (×)", image: nil) { _ in
            self.selectedOperation = "*"
            self.operationButton.setTitle("Multiplication (×)", for: .normal)
        }

       
        let menu = UIMenu(title: "Select Operation", children: [suma, resta, multi])
        
        operationButton.menu = menu
        operationButton.showsMenuAsPrimaryAction = true 
    }

    // MARK: - Acción de Calcular
    @IBAction func calcularPressed(_ sender: UIButton) {
        
        // Validamos que haya números
        guard let text1 = firstNumberTextField.text, let num1 = Double(text1),
              let text2 = secondNumberTextField.text, let num2 = Double(text2) else {
            resultLabel.text = "Error: Invalid numbers"
            return
        }

        var total: Double = 0

        // Lógica según la operación guardada
        switch selectedOperation {
        case "+":
            total = num1 + num2
        case "-":
            total = num1 - num2
        case "*":
            total = num1 * num2
        default:
            break
        }

        // Mostramos el resultado en el Label
        resultLabel.text = "Total: \(total)"
    }
}
