//
//  ViewController.swift
//  apple_lab08_pract02_UIKit
//
//  Created by Jaime Gomez on 4/5/25.
//

import UIKit

class TeacherController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return listaProfesores.count
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "celda")!
        
        cell.textLabel?.text=listaProfesores[indexPath.row].nombre
        cell.detailTextLabel?.text=String(listaProfesores[indexPath.row].cargo)
        cell.imageView?.image=listaProfesores[indexPath.row].foto!
        return cell
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Teacher List"
    }
    
    var listaProfesores=[
        Profesor(nombre: "jaime gomez", cargo: "coordinador",foto:UIImage(named: "image1")),
        Profesor(nombre: "jaime gomez", cargo: "coordinador",foto:UIImage(named: "image2")),
        Profesor(nombre: "jaime gomez", cargo: "coordinador",foto:UIImage(named: "image3")),
        Profesor(nombre: "jaime gomez", cargo: "coordinador",foto:UIImage(named: "image4")),
    ]


}

